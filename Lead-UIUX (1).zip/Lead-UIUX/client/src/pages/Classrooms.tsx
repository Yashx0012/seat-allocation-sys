import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Trash2, Maximize2, Save, GripHorizontal, Box } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

// Mock Layout Data
const INITIAL_ROWS = 6;
const INITIAL_COLS = 8;

export default function Classrooms() {
  const [roomName, setRoomName] = useState("Lecture Hall A1");
  const [rows, setRows] = useState(INITIAL_ROWS);
  const [cols, setCols] = useState(INITIAL_COLS);
  const [seats, setSeats] = useState(
    Array.from({ length: INITIAL_ROWS * INITIAL_COLS }, (_, i) => ({
      id: i,
      status: "active", // active, broken, hidden
    }))
  );

  const handleSeatClick = (id: number) => {
    setSeats((prev) =>
      prev.map((seat) =>
        seat.id === id
          ? { ...seat, status: seat.status === "active" ? "broken" : "active" }
          : seat
      )
    );
  };

  const updateGrid = (newRows: number, newCols: number) => {
    setRows(newRows);
    setCols(newCols);
    setSeats(
      Array.from({ length: newRows * newCols }, (_, i) => ({
        id: i,
        status: "active",
      }))
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="h-[calc(100vh-140px)] flex flex-col md:flex-row gap-6"
    >
      {/* Left Controls */}
      <div className="w-full md:w-80 shrink-0 space-y-6">
        <div className="glass-card p-6 space-y-6">
          <div className="flex items-center gap-2 mb-2">
            <Box className="w-5 h-5 text-primary" />
            <h2 className="font-bold uppercase tracking-wider">Room Config</h2>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <label className="micro-label">Room Identifier</label>
              <Input 
                value={roomName}
                onChange={(e) => setRoomName(e.target.value)}
                className="h-14 bg-secondary border-transparent focus:border-primary focus:ring-2 focus:ring-primary/20 text-lg font-mono rounded-xl transition-all"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="micro-label">Rows</label>
                <Input 
                  type="number"
                  value={rows}
                  onChange={(e) => updateGrid(Number(e.target.value), cols)}
                  className="h-14 bg-secondary border-transparent text-lg font-mono rounded-xl text-center"
                />
              </div>
              <div className="space-y-2">
                <label className="micro-label">Columns</label>
                <Input 
                  type="number"
                  value={cols}
                  onChange={(e) => updateGrid(rows, Number(e.target.value))}
                  className="h-14 bg-secondary border-transparent text-lg font-mono rounded-xl text-center"
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-border">
             <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
               <span>Total Capacity</span>
               <span className="font-mono text-foreground text-lg">{rows * cols}</span>
             </div>
             
             <div className="flex gap-2 text-xs text-muted-foreground mb-6">
               <div className="flex items-center gap-1">
                 <div className="w-3 h-3 rounded bg-secondary border border-border"></div> Active
               </div>
               <div className="flex items-center gap-1">
                 <div className="w-3 h-3 rounded bg-destructive/20 border border-destructive/50"></div> Broken
               </div>
             </div>

             <Button className="w-full h-14 bg-gradient-to-r from-primary to-primary/80 hover:shadow-lg hover:shadow-primary/25 rounded-2xl text-md font-bold tracking-wide transition-all">
               <Save className="w-4 h-4 mr-2" />
               Save Blueprint
             </Button>
          </div>
        </div>
      </div>

      {/* Right Canvas */}
      <div className="flex-1 glass-card p-8 flex flex-col relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/50 to-transparent"></div>
        
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-black text-foreground">{roomName}</h2>
          <div className="flex gap-2">
             <Button variant="ghost" size="icon" className="hover:bg-secondary rounded-xl text-muted-foreground">
               <GripHorizontal className="w-5 h-5" />
             </Button>
             <Button variant="ghost" size="icon" className="hover:bg-secondary rounded-xl text-muted-foreground">
               <Maximize2 className="w-5 h-5" />
             </Button>
          </div>
        </div>

        {/* The Grid */}
        <div className="flex-1 flex items-center justify-center overflow-auto custom-scrollbar p-4 bg-background/30 rounded-[1.5rem] border border-border relative">
          
          <div className="absolute inset-0 opacity-[0.05]" 
               style={{ 
                 backgroundImage: 'linear-gradient(currentColor 1px, transparent 1px), linear-gradient(90deg, currentColor 1px, transparent 1px)',
                 backgroundSize: '40px 40px'
               }}>
          </div>

          <div 
            className="grid gap-3 transition-all duration-500 ease-in-out"
            style={{
              gridTemplateColumns: `repeat(${cols}, minmax(40px, 1fr))`,
              width: 'fit-content'
            }}
          >
            {seats.map((seat) => (
              <motion.button
                key={seat.id}
                layout
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => handleSeatClick(seat.id)}
                className={`
                  w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center text-xs font-mono transition-colors duration-300 relative
                  ${seat.status === 'active' 
                    ? 'bg-secondary text-muted-foreground hover:bg-primary/10 hover:text-primary border border-border' 
                    : 'bg-destructive/10 text-destructive border border-destructive/30 shadow-[0_0_15px_rgba(var(--destructive),0.15)]'
                  }
                `}
              >
                 {seat.status === 'broken' && (
                   <div className="absolute inset-0 flex items-center justify-center">
                     <div className="w-full h-px bg-destructive/50 transform rotate-45"></div>
                   </div>
                 )}
                 {seat.id + 1}
              </motion.button>
            ))}
          </div>
        </div>
        
        <div className="mt-4 flex justify-center">
          <div className="px-6 py-2 bg-secondary rounded-full border border-border text-xs text-muted-foreground font-mono tracking-widest">
            STAGE / FRONT
          </div>
        </div>
      </div>
    </motion.div>
  );
}
