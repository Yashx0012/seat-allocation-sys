import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { 
  Users, 
  Map, 
  Cpu, 
  AlertCircle, 
  ArrowUpRight,
  Terminal
} from "lucide-react";

// Mock Data
const stats = [
  { label: "Total Students", value: 12450, icon: Users, color: "text-blue-500" },
  { label: "Active Rooms", value: 48, icon: Map, color: "text-emerald-500" },
  { label: "Allocation Rate", value: "94%", icon: Cpu, color: "text-indigo-500" },
  { label: "Conflicts", value: 3, icon: AlertCircle, color: "text-red-500" },
];

const activityLog = [
  { id: 1, time: "10:42:05", message: "Room 304 capacity updated to 60 seats", type: "info" },
  { id: 2, time: "10:40:12", message: "Batch CS-2024 allocation initiated", type: "process" },
  { id: 3, time: "10:38:55", message: "Conflict detected in Hall B (Seat 12)", type: "warning" },
  { id: 4, time: "10:35:00", message: "System synchronized with main database", type: "success" },
  { id: 5, time: "10:31:22", message: "User admin_01 logged in", type: "info" },
];

const StatCard = ({ stat, index }: { stat: any, index: number }) => {
  const [count, setCount] = useState<number | string>(0);

  useEffect(() => {
    // Simple counter animation
    const duration = 1500;
    const steps = 60;
    const interval = duration / steps;
    const target = typeof stat.value === 'number' ? stat.value : parseInt(stat.value);
    
    if (isNaN(target)) {
      setCount(stat.value);
      return;
    }

    let current = 0;
    const timer = setInterval(() => {
      current += target / steps;
      if (current >= target) {
        current = target;
        clearInterval(timer);
      }
      setCount(typeof stat.value === 'string' && stat.value.includes('%') ? Math.floor(current) + '%' : Math.floor(current));
    }, interval);

    return () => clearInterval(timer);
  }, [stat.value]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      className="glass-card relative overflow-hidden p-6 hover:scale-[1.01] hover:shadow-2xl hover:shadow-primary/10 transition-all duration-300 group"
    >
      <div className="absolute top-0 right-0 p-4 opacity-5 transform rotate-12 group-hover:scale-110 transition-transform duration-500">
        <stat.icon className="w-24 h-24 text-foreground" />
      </div>
      
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          <div className="p-2 rounded-xl bg-secondary border border-border">
            <stat.icon className={`w-6 h-6 ${stat.color}`} />
          </div>
          <div className="flex items-center gap-1 text-xs font-mono text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded-full">
            <ArrowUpRight className="w-3 h-3" />
            <span>+2.4%</span>
          </div>
        </div>
        
        <div className="space-y-1">
          <h3 className="micro-label">System Metric</h3>
          <div className="text-4xl font-black tracking-tight text-foreground font-mono">
            {count}
          </div>
          <p className="text-sm text-muted-foreground font-medium">{stat.label}</p>
        </div>
      </div>
    </motion.div>
  );
};

export default function Dashboard() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-8"
    >
      {/* Hero Section */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-border">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <div className="relative w-3 h-3">
              <div className="absolute inset-0 bg-emerald-500 rounded-full animate-ping opacity-75"></div>
              <div className="relative w-3 h-3 bg-emerald-500 rounded-full border border-emerald-400"></div>
            </div>
            <span className="text-xs font-mono text-emerald-500 tracking-wider uppercase">Live Connection</span>
          </div>
          <h1 className="text-4xl md:text-5xl bg-gradient-to-r from-foreground via-foreground/80 to-foreground/50 bg-clip-text text-transparent">
            Good Morning, <br />Administrator
          </h1>
        </div>
        
        <div className="flex gap-4">
          <div className="text-right hidden md:block">
            <div className="micro-label mb-1">Current Session</div>
            <div className="font-mono text-xl text-foreground">Fall Semester 2025</div>
          </div>
          <div className="w-px bg-border h-12 hidden md:block"></div>
          <div className="text-right">
            <div className="micro-label mb-1">Next Exam</div>
            <div className="font-mono text-xl text-primary">08:00 AM</div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <StatCard key={stat.label} stat={stat} index={i} />
        ))}
      </div>

      {/* Activity Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Chart Area Placeholder */}
        <div className="lg:col-span-2 glass-card min-h-[400px] p-6 flex flex-col relative overflow-hidden">
           <div className="flex justify-between items-center mb-6">
             <h2 className="text-xl">Allocation Velocity</h2>
             <div className="flex gap-2">
               {['1H', '24H', '7D', '30D'].map((t, i) => (
                 <button key={t} className={`px-3 py-1 rounded-lg text-xs font-mono transition-colors ${i === 1 ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground hover:bg-secondary/80'}`}>
                   {t}
                 </button>
               ))}
             </div>
           </div>
           
           {/* Decorative Graph Lines */}
           <div className="flex-1 w-full relative">
             <svg className="w-full h-full" viewBox="0 0 800 300" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="gradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--color-primary)" stopOpacity="0.5" />
                    <stop offset="100%" stopColor="var(--color-primary)" stopOpacity="0" />
                  </linearGradient>
                </defs>
                <path 
                  d="M0,250 C100,200 200,280 300,150 C400,20 500,100 600,80 C700,60 800,100 800,100 V300 H0 Z" 
                  fill="url(#gradient)" 
                  className="opacity-20"
                />
                <path 
                  d="M0,250 C100,200 200,280 300,150 C400,20 500,100 600,80 C700,60 800,100 800,100" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="3"
                  className="text-primary"
                  vectorEffect="non-scaling-stroke"
                />
             </svg>
             
             {/* Data Points */}
             <div className="absolute top-1/2 left-1/3 w-3 h-3 bg-primary rounded-full shadow-[0_0_15px_rgba(var(--color-primary),1)] border-2 border-background"></div>
           </div>
        </div>

        {/* Terminal Log */}
        <div className="glass-card p-6 flex flex-col h-[400px]">
          <div className="flex items-center gap-2 mb-6 pb-4 border-b border-border">
            <Terminal className="w-5 h-5 text-muted-foreground" />
            <h2 className="text-sm font-bold tracking-widest uppercase">System Log</h2>
          </div>
          
          <div className="flex-1 overflow-y-auto pr-2 space-y-4 font-mono text-sm">
            {activityLog.map((log, i) => (
              <motion.div
                key={log.id}
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: i * 0.1 }}
                className="flex gap-3 group"
              >
                <div className="w-16 text-[10px] text-muted-foreground pt-1 shrink-0">{log.time}</div>
                <div className="flex flex-col">
                  <span className={`text-xs ${
                    log.type === 'warning' ? 'text-amber-500' :
                    log.type === 'success' ? 'text-emerald-500' :
                    log.type === 'process' ? 'text-primary' :
                    'text-foreground/80'
                  }`}>
                    {log.type === 'warning' ? '⚠ ' : 
                     log.type === 'success' ? '✓ ' :
                     log.type === 'process' ? '⚙ ' : '> '}
                    {log.message}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
