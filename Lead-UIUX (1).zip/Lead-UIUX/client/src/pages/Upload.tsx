import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Upload as UploadIcon, 
  FileText, 
  X, 
  Check, 
  Database, 
  AlertCircle,
  Eye,
  FileSpreadsheet
} from "lucide-react";
import { Button } from "@/components/ui/button";

// Mock parsed data
const MOCK_PARSED_DATA = [
  { id: 1, name: "John Doe", roll: "2024001", department: "CS", year: "4th" },
  { id: 2, name: "Jane Smith", roll: "2024002", department: "CS", year: "4th" },
  { id: 3, name: "Mike Ross", roll: "2024003", department: "ME", year: "3rd" },
  { id: 4, name: "Harvey Specter", roll: "2024004", department: "LAW", year: "2nd" },
  { id: 5, name: "Donna Paulsen", roll: "2024005", department: "ADMIN", year: "4th" },
];

export default function Upload() {
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [isCommitted, setIsCommitted] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      if (selectedFile.size > 5 * 1024 * 1024) {
        alert("File size exceeds 5MB limit");
        return;
      }
      setFile(selectedFile);
    }
  };

  const handleUpload = () => {
    setIsUploading(true);
    setTimeout(() => {
      setIsUploading(false);
      setShowPreview(true);
    }, 1500);
  };

  const handleCommit = () => {
    setIsCommitted(true);
    setTimeout(() => {
      setIsCommitted(false);
      setFile(null);
      setShowPreview(false);
    }, 3000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-8"
    >
      <div className="flex flex-col gap-2">
        <h1 className="text-4xl">Data Ingestion</h1>
        <p className="text-muted-foreground font-mono text-sm uppercase tracking-widest">Upload Student & Batch Records</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Upload Zone */}
        <div className="space-y-6">
          <div className="glass-card p-8 flex flex-col items-center justify-center min-h-[400px] border-dashed border-2 relative">
            {!file ? (
              <>
                <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-6">
                  <UploadIcon className="w-10 h-10 text-primary" />
                </div>
                <div className="text-center space-y-2">
                  <h2 className="text-xl font-bold uppercase">Drop your files here</h2>
                  <p className="text-sm text-muted-foreground">Support CSV, XLSX formats up to 5MB</p>
                </div>
                <input 
                  type="file" 
                  className="absolute inset-0 opacity-0 cursor-pointer" 
                  accept=".csv, .xlsx"
                  onChange={handleFileChange}
                />
              </>
            ) : (
              <div className="w-full space-y-6">
                <div className="flex items-center gap-4 p-4 bg-secondary rounded-2xl border border-border">
                  <div className="p-3 rounded-xl bg-primary/10 text-primary">
                    <FileSpreadsheet className="w-8 h-8" />
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <div className="font-bold truncate">{file.name}</div>
                    <div className="text-xs text-muted-foreground">{(file.size / 1024 / 1024).toFixed(2)} MB</div>
                  </div>
                  <button onClick={() => setFile(null)} className="p-2 hover:bg-destructive/10 hover:text-destructive rounded-full transition-colors">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {!showPreview && (
                  <Button 
                    onClick={handleUpload}
                    disabled={isUploading}
                    className="w-full h-14 bg-primary text-primary-foreground text-lg font-bold rounded-2xl"
                  >
                    {isUploading ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        <span>PARSING DATA...</span>
                      </div>
                    ) : (
                      <span>PROCESS FILE</span>
                    )}
                  </Button>
                )}
              </div>
            )}
          </div>

          <div className="glass-card p-6 space-y-4">
            <h3 className="micro-label">Requirements</h3>
            <ul className="space-y-2 text-xs text-muted-foreground font-mono">
              <li className="flex items-center gap-2"><Check className="w-3 h-3 text-emerald-500" /> Header row must contain Name, Roll, Dept</li>
              <li className="flex items-center gap-2"><Check className="w-3 h-3 text-emerald-500" /> Max file size: 5,120 KB</li>
              <li className="flex items-center gap-2"><Check className="w-3 h-3 text-emerald-500" /> Duplicates will be ignored</li>
            </ul>
          </div>
        </div>

        {/* Preview Zone */}
        <AnimatePresence>
          {showPreview && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-6"
            >
              <div className="glass-card p-0 flex flex-col h-full overflow-hidden min-h-[500px]">
                <div className="p-6 border-b border-border flex justify-between items-center bg-secondary/30">
                  <div className="flex items-center gap-3">
                    <Eye className="w-5 h-5 text-primary" />
                    <h2 className="font-bold uppercase tracking-wider">Data Preview</h2>
                  </div>
                  <div className="text-[10px] font-mono bg-emerald-500/10 text-emerald-500 px-2 py-1 rounded-full border border-emerald-500/20">
                    5 RECORDS FOUND
                  </div>
                </div>

                <div className="flex-1 overflow-auto custom-scrollbar">
                  <table className="w-full text-left font-mono text-xs">
                    <thead className="bg-secondary/50 sticky top-0">
                      <tr>
                        <th className="p-4 border-b border-border">NAME</th>
                        <th className="p-4 border-b border-border">ROLL</th>
                        <th className="p-4 border-b border-border">DEPT</th>
                        <th className="p-4 border-b border-border">YEAR</th>
                      </tr>
                    </thead>
                    <tbody>
                      {MOCK_PARSED_DATA.map((row) => (
                        <tr key={row.id} className="border-b border-border/50 hover:bg-primary/5 transition-colors">
                          <td className="p-4 font-bold text-foreground">{row.name}</td>
                          <td className="p-4 text-primary">{row.roll}</td>
                          <td className="p-4">{row.department}</td>
                          <td className="p-4">{row.year}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="p-6 bg-secondary/30 border-t border-border mt-auto">
                  <Button 
                    onClick={handleCommit}
                    disabled={isCommitted}
                    className={`w-full h-14 text-lg font-bold rounded-2xl transition-all duration-500 ${
                      isCommitted ? "bg-emerald-500 hover:bg-emerald-500 cursor-default" : "bg-primary"
                    }`}
                  >
                    {isCommitted ? (
                      <div className="flex items-center gap-2">
                        <Check className="w-6 h-6" />
                        <span>COMMITTED TO DATABASE</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <Database className="w-5 h-5" />
                        <span>COMMIT TO DATABASE</span>
                      </div>
                    )}
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
