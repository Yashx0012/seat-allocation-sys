import React, { useState } from "react";
import { motion } from "framer-motion";
import { 
  User, 
  Mail, 
  Shield, 
  Key, 
  QrCode,
  Fingerprint
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function Profile() {
  const [isEditing, setIsEditing] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="flex items-center justify-center py-12"
    >
      <div className="relative w-full max-w-2xl">
        <div className="glass-card overflow-hidden relative border-t border-border shadow-2xl shadow-primary/20">
          <div className="h-48 bg-primary/10 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-primary/10 to-transparent"></div>
            <div className="absolute inset-0 opacity-10" 
                 style={{ 
                   backgroundImage: 'radial-gradient(currentColor 1px, transparent 1px)',
                   backgroundSize: '20px 20px'
                 }}>
            </div>
            <div className="absolute top-6 right-6">
              <Fingerprint className="w-12 h-12 text-primary/20" />
            </div>
          </div>

          <div className="absolute top-24 left-10">
            <div className="relative">
              <div className="w-32 h-32 rounded-full p-1 bg-background ring-4 ring-border">
                 <Avatar className="w-full h-full border-4 border-background">
                  <AvatarImage src="https://github.com/shadcn.png" />
                  <AvatarFallback className="bg-secondary text-2xl font-bold">AD</AvatarFallback>
                </Avatar>
              </div>
              <div className="absolute bottom-1 right-1 w-6 h-6 bg-emerald-500 rounded-full border-4 border-background"></div>
            </div>
          </div>

          <div className="pt-20 px-10 pb-10 bg-card/80 backdrop-blur-sm">
            <div className="flex justify-between items-start mb-8">
              <div>
                <h1 className="text-3xl font-black text-foreground">Administrator</h1>
                <p className="text-primary font-mono text-sm mt-1">SYSTEM LEVEL 5 CLEARANCE</p>
              </div>
              <Button onClick={() => setIsEditing(!isEditing)} variant="outline" className="rounded-full border-border hover:bg-secondary">
                {isEditing ? 'Cancel Edit' : 'Edit Profile'}
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="flex items-center gap-2 micro-label"><User className="w-3 h-3" /> Full Name</label>
                  {isEditing ? <Input defaultValue="Alex Chen" className="bg-secondary border-border" /> : <div className="text-lg font-medium text-foreground border-b border-dashed border-border pb-2">Alex Chen</div>}
                </div>
                <div className="space-y-2">
                  <label className="flex items-center gap-2 micro-label"><Shield className="w-3 h-3" /> Department</label>
                  {isEditing ? <Input defaultValue="Examination Cell" className="bg-secondary border-border" /> : <div className="text-lg font-medium text-foreground border-b border-dashed border-border pb-2">Examination Cell</div>}
                </div>
              </div>
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="flex items-center gap-2 micro-label"><Mail className="w-3 h-3" /> Email Address</label>
                  {isEditing ? <Input defaultValue="alex.c@university.edu" className="bg-secondary border-border" /> : <div className="text-lg font-medium text-foreground border-b border-dashed border-border pb-2 font-mono">alex.c@university.edu</div>}
                </div>
                <div className="space-y-2">
                  <label className="flex items-center gap-2 micro-label"><Key className="w-3 h-3" /> Employee ID</label>
                  <div className="text-lg font-medium text-muted-foreground font-mono">8829-X-2025</div>
                </div>
              </div>
            </div>

            <div className="mt-10 pt-6 border-t border-border flex items-center justify-between">
              <div className="flex gap-4">
                 <div className="bg-foreground p-2 rounded-lg">
                   <QrCode className="w-12 h-12 text-background" />
                 </div>
                 <div className="flex flex-col justify-center gap-1">
                   <span className="micro-label">Scan for Access</span>
                   <span className="text-[10px] text-muted-foreground font-mono">TOKEN: 8f7d-2a9c-4b1e</span>
                 </div>
              </div>
              {isEditing && <Button className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl px-8">Save Changes</Button>}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
