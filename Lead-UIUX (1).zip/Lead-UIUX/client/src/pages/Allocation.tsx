import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Play, 
  RotateCcw, 
  Settings2, 
  Database, 
  ArrowDownWideNarrow,
  Download,
  Check,
  Cpu,
  Plus
} from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";

// Mock Batches
const BATCHES = [
  { id: "CS-24", name: "Comp Sci 2024", color: "bg-blue-500", startRoll: "2024001" },
  { id: "ME-24", name: "Mech Eng 2024", color: "bg-amber-500", startRoll: "2024501" },
  { id: "EE-24", name: "Elec Eng 2024", color: "bg-purple-500", startRoll: "2024801" },
];

interface AllocatedSeat {
  id: number;
  seatNo: number;
  batch: typeof BATCHES[0];
  roll: number;
}

export default function Allocation() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [isGenerated, setIsGenerated] = useState(false);
  const [allocatedSeats, setAllocatedSeats] = useState<AllocatedSeat[]>([]);

  const handleGenerate = () => {
    setIsGenerating(true);
    setIsGenerated(false);
    setAllocatedSeats([]);

    setTimeout(() => {
      setIsGenerating(false);
      setIsGenerated(true);
      const newSeats = Array.from({ length: 48 }, (_, i) => {
        const batch = BATCHES[i % BATCHES.length];
        const roll = parseInt(batch.startRoll) + Math.floor(i / BATCHES.length);
        return {
          id: i,
          seatNo: i + 1,
          batch: batch,
          roll: roll
        };
      });
      setAllocatedSeats(newSeats);
    }, 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="h-[calc(100vh-140px)] flex flex-col lg:flex-row gap-6"
    >
      <div className="w-full lg:w-96 shrink-0 space-y-6">
        <div className="glass-card p-6 space-y-8 h-full flex flex-col">
          <div className="space-y-6">
             <div className="flex items-center gap-2 mb-6">
              <Settings2 className="w-5 h-5 text-primary" />
              <h2 className="font-bold uppercase tracking-wider">Allocation Logic</h2>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-2xl bg-secondary border border-border">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10 text-primary">
                    <Database className="w-4 h-4" />
                  </div>
                  <div className="text-sm font-medium">Use Database</div>
                </div>
                <Switch />
              </div>

              <div className="flex items-center justify-between p-4 rounded-2xl bg-secondary border border-border">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10 text-primary">
                    <ArrowDownWideNarrow className="w-4 h-4" />
                  </div>
                  <div className="text-sm font-medium">Fill Column-wise</div>
                </div>
                <Switch defaultChecked />
              </div>
            </div>
          </div>

          <div className="space-y-4 flex-1">
            <h3 className="micro-label">Active Batches</h3>
            <div className="space-y-3">
              {BATCHES.map((batch) => (
                <div key={batch.id} className="group relative overflow-hidden bg-secondary rounded-2xl p-4 border border-border hover:border-primary/50 transition-colors">
                  <div className={`absolute top-0 left-0 w-1 h-full ${batch.color}`}></div>
                  <div className="flex justify-between items-center relative z-10">
                    <div>
                      <div className="text-sm font-bold text-foreground">{batch.name}</div>
                      <div className="text-xs text-muted-foreground font-mono mt-1">Start: {batch.startRoll}</div>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${batch.color} opacity-50`}></div>
                  </div>
                </div>
              ))}
            </div>
            
            <button className="w-full py-4 rounded-2xl border border-dashed border-border text-muted-foreground text-xs font-bold hover:bg-secondary hover:text-foreground hover:border-primary/50 transition-all duration-200 flex items-center justify-center gap-2 group">
              <Plus className="w-4 h-4 transition-transform group-hover:rotate-90" />
              <span>ADD BATCH SEQUENCE</span>
            </button>
          </div>

          <div className="pt-6 mt-auto">
            <Button 
              onClick={handleGenerate}
              disabled={isGenerating}
              className="w-full h-14 bg-gradient-to-r from-primary to-primary/80 hover:shadow-lg hover:shadow-primary/25 rounded-2xl text-md font-bold tracking-wide transition-all relative overflow-hidden"
            >
              {isGenerating ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  <span>PROCESSING...</span>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Play className="w-4 h-4 fill-primary-foreground" />
                  <span>GENERATE PLAN</span>
                </div>
              )}
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 glass-card p-0 flex flex-col relative overflow-hidden">
        <div className="p-6 border-b border-border flex justify-between items-center bg-secondary/30">
          <div className="flex items-center gap-4">
             <div className="text-2xl font-black text-foreground">Lecture Hall A1</div>
             {isGenerated && (
               <div className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-500 text-xs font-bold border border-emerald-500/20 flex items-center gap-1">
                 <Check className="w-3 h-3" /> READY
               </div>
             )}
          </div>
          <div className="flex gap-2">
             <Button variant="outline" size="sm" className="h-10 border-border bg-transparent hover:bg-secondary">
               <RotateCcw className="w-4 h-4 mr-2" /> Reset
             </Button>
             <Button variant="outline" size="sm" className="h-10 border-border bg-transparent hover:bg-secondary">
               <Download className="w-4 h-4 mr-2" /> Export
             </Button>
          </div>
        </div>

        <div className="flex-1 bg-background/50 p-8 overflow-y-auto custom-scrollbar">
          {!isGenerated && !isGenerating && (
            <div className="h-full flex flex-col items-center justify-center text-muted-foreground/30">
              <Cpu className="w-24 h-24 mb-6" />
              <p className="text-lg font-medium text-muted-foreground/50">Ready to initialize allocation sequence</p>
            </div>
          )}

          {isGenerating && (
            <div className="h-full flex flex-col items-center justify-center">
              <div className="relative w-32 h-32">
                 <div className="absolute inset-0 border-4 border-secondary rounded-full"></div>
                 <div className="absolute inset-0 border-4 border-primary rounded-full border-t-transparent animate-spin"></div>
              </div>
              <p className="mt-8 font-mono text-primary animate-pulse">OPTIMIZING SEATING LOGIC...</p>
            </div>
          )}

          {isGenerated && (
            <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-4">
              {allocatedSeats.map((seat, i) => (
                <motion.div
                  key={seat.id}
                  initial={{ opacity: 0, scale: 0.8, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  transition={{ delay: i * 0.03, type: "spring", stiffness: 200, damping: 15 }}
                  className="bg-secondary rounded-xl border border-border p-3 flex flex-col items-center justify-center gap-1 hover:border-primary/50 transition-colors group cursor-pointer relative overflow-hidden"
                >
                  <div className={`absolute top-0 inset-x-0 h-1 ${seat.batch.color}`}></div>
                  <span className="text-[9px] font-bold text-muted-foreground uppercase tracking-wider">{seat.batch.name.split(' ')[0]}</span>
                  <span className="text-lg font-mono font-bold text-foreground group-hover:text-primary transition-colors">{seat.roll}</span>
                  <div className="px-2 py-0.5 rounded bg-background text-[10px] text-muted-foreground font-mono mt-1">S-{seat.seatNo}</div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
