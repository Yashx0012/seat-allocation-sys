import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";

import Navbar from "@/components/Navbar";
import Dashboard from "@/pages/Dashboard.tsx";
import Classrooms from "@/pages/Classrooms.tsx";
import Allocation from "@/pages/Allocation.tsx";
import Upload from "@/pages/Upload.tsx";
import Profile from "@/pages/Profile.tsx";
import NotFound from "@/pages/not-found";

function Router() {
  const [location] = useLocation();

  return (
    <AnimatePresence mode="wait">
      <Switch location={location} key={location}>
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/classrooms" component={Classrooms} />
        <Route path="/allocation" component={Allocation} />
        <Route path="/upload" component={Upload} />
        <Route path="/profile" component={Profile} />
        
        {/* Default redirect to dashboard */}
        <Route path="/">
          <Redirect to="/dashboard" />
        </Route>
        
        <Route component={NotFound} />
      </Switch>
    </AnimatePresence>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen selection:bg-primary/30 font-sans pb-20 transition-colors duration-300">
        <Navbar />
        <main className="pt-32 px-4 md:px-8 max-w-7xl mx-auto">
          <Router />
        </main>
      </div>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
