import React from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { useTheme } from "next-themes";
import { 
  LayoutDashboard, 
  Grid3X3, 
  Cpu, 
  User, 
  Sun, 
  Moon,
  Upload
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function Navbar() {
  const [location] = useLocation();
  const { theme, setTheme } = useTheme();

  const navItems = [
    { path: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { path: "/classrooms", label: "Registry", icon: Grid3X3 },
    { path: "/allocation", label: "Allocation", icon: Cpu },
    { path: "/upload", label: "Upload", icon: Upload },
    { path: "/profile", label: "Profile", icon: User },
  ];

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  return (
    <motion.nav 
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: "circOut" }}
      className="fixed top-4 left-0 right-0 z-50 w-[95%] max-w-7xl mx-auto"
    >
      <div className="glass-panel rounded-2xl px-6 h-20 flex items-center justify-between shadow-2xl shadow-black/50 dark:shadow-black/50">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Cpu className="text-white w-6 h-6" />
          </div>
          <div>
            <h1 className="text-lg leading-none bg-gradient-to-r from-slate-900 dark:from-white to-slate-600 dark:to-slate-400 bg-clip-text text-transparent">
              SeatAlloc
            </h1>
            <span className="micro-label text-[8px] text-blue-600 dark:text-blue-400">System v2.0</span>
          </div>
        </div>

        {/* Navigation Links */}
        <div className="hidden md:flex items-center gap-1 bg-slate-100 dark:bg-slate-900/50 p-1 rounded-xl border border-slate-200 dark:border-white/5">
          {navItems.map((item) => {
            const isActive = location === item.path;
            const Icon = item.icon;
            
            return (
              <Link key={item.path} href={item.path}>
                <div 
                  className={`relative px-4 py-2 rounded-lg cursor-pointer transition-colors duration-200 flex items-center gap-2 ${
                    isActive 
                      ? "text-slate-900 dark:text-white" 
                      : "text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{item.label}</span>
                  
                  {isActive && (
                    <motion.div
                      layoutId="nav-indicator"
                      className="absolute inset-0 bg-white/10 dark:bg-white/10 rounded-lg border border-slate-300 dark:border-white/10"
                      transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                </div>
              </Link>
            );
          })}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-4">
          <motion.button 
            onClick={toggleTheme}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="w-10 h-10 rounded-full hover:bg-slate-200 dark:hover:bg-white/5 flex items-center justify-center transition-colors"
            data-testid="button-toggle-theme"
          >
            {theme === "dark" ? (
              <Sun className="w-5 h-5 text-slate-600 dark:text-slate-400" />
            ) : (
              <Moon className="w-5 h-5 text-slate-600 dark:text-slate-400" />
            )}
          </motion.button>
          
          <div className="h-8 w-px bg-slate-200 dark:bg-white/10" />
          
          <div className="flex items-center gap-3 pl-2">
            <div className="text-right hidden sm:block">
              <div className="text-xs font-bold text-slate-900 dark:text-white">Admin User</div>
              <div className="text-[10px] text-slate-600 dark:text-slate-400 font-mono">ID: 8829-X</div>
            </div>
            <Avatar className="h-10 w-10 border-2 border-slate-200 dark:border-slate-700">
              <AvatarImage src="https://github.com/shadcn.png" />
              <AvatarFallback>AD</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </div>
    </motion.nav>
  );
}
